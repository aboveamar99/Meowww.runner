import { Engine } from './game-engine/core/Engine.js';
import { GameStateManager } from './game-engine/state/GameStateManager.js';
import { MenuState } from './states/MenuState.js';

const canvas=document.getElementById('gameCanvas');
canvas.width=window.innerWidth;
canvas.height=window.innerHeight;

class Game{
 constructor(){
  this.engine=new Engine();
  this.stateManager=new GameStateManager();
  this.stateManager.registerState('menu',new MenuState(this));
  this.stateManager.changeState('menu');

  this.engine.addUpdateCallback(dt=>this.stateManager.update(dt));
  this.engine.addRenderCallback(()=>this.stateManager.render(canvas.getContext('2d')));
  this.engine.start();
 }
}

window.game=new Game();
