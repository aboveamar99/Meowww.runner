export class GameStateManager{
 constructor(){this.states=new Map();this.current=null;}
 registerState(n,s){this.states.set(n,s);}
 changeState(n){this.current=this.states.get(n); if(this.current.enter)this.current.enter();}
 update(dt){if(this.current?.update)this.current.update(dt)}
 render(ctx){if(this.current?.render)this.current.render(ctx)}
}