export class Engine{
 constructor(){this.last=0;this.updateCallbacks=new Set();this.renderCallbacks=new Set();}
 addUpdateCallback(cb){this.updateCallbacks.add(cb)}
 addRenderCallback(cb){this.renderCallbacks.add(cb)}
 start(){this.last=performance.now();this.loop(this.last)}
 loop(t){
  requestAnimationFrame(e=>this.loop(e));
  const dt=(t-this.last)/1000;this.last=t;
  this.updateCallbacks.forEach(cb=>cb(dt));
  this.renderCallbacks.forEach(cb=>cb(dt));
 }
}