export class MenuState{
 constructor(game){this.game=game;}
 enter(){console.log("Menu Loaded")}
 update(){}
 render(ctx){
  ctx.clearRect(0,0,ctx.canvas.width,ctx.canvas.height);
  ctx.fillStyle="white";
  ctx.fillText("Game Working!",50,50);
 }
}